PAWORA DEMO WEBSITE

How to preview:
1. Extract the ZIP file.
2. Open the pawora_pet_store folder.
3. Double-click index.html to open it in your browser.

What is included:
- Responsive pet-store homepage
- Product cards for grooming glove and comb
- Demo basket interactions
- Demo newsletter form (does not collect or send email)
- Mobile-friendly layout

Before using it for real sales:
- Check whether the Pawora name is available and safe to use.
- Replace placeholder prices with real prices.
- Replace emoji artwork with product images you have permission to use.
- Add accurate delivery, returns, contact and privacy information.
- This demo has no secure checkout and cannot accept payments or process orders.
- A static HTML website must be uploaded to a hosting provider to be publicly available.
